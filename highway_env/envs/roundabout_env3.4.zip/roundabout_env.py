from random import random
import random as rand
from typing import Tuple
from xmlrpc.client import TRANSPORT_ERROR

from gym.envs.registration import register
import numpy as np
from sqlalchemy import true

from highway_env import utils
from highway_env.envs.common.abstract import AbstractEnv
from highway_env.road.lane import LineType, StraightLane, CircularLane, SineLane
from highway_env.road.road import Road, RoadNetwork
from highway_env.vehicle.controller import MDPVehicle
from highway_env.vehicle.uncertainty.prediction import IntervalVehicle


class RoundaboutEnv(AbstractEnv):

    @classmethod
    def default_config(cls) -> dict:
        config = super().default_config()
        config.update({
            "observation": {
                "type": "Kinematics",
                "absolute": True,
                "features_range": {"x": [-100, 100], "y": [-100, 100], "vx": [-15, 15], "vy": [-15, 15]},
                "features": ["presence", "x", "y", "vx", "vy", "cos_h", "sin_h"],
            },
            "action": {
                "type": "DiscreteMetaAction",
            },
            "incoming_vehicle_destination": None,
            "my_other_vehicles_type":"highway_env.vehicle.uncertainty.estimation.MultipleModelVehicle",
            #"my_other_vehicles_type":"highway_env.vehicle.uncertainty.estimation.IntervalVehicle",
            
            "collision_reward": -1,
            "high_speed_reward": 0.2,
            "right_lane_reward": 0,
            "lane_change_reward": -0.05,
            "v_is_zero_reward":-1,
            "collision_incoming":-0.1,
            "screen_width": 600,
            "screen_height": 600,
            "centering_position": [0.5, 0.6],
            "duration": 10,
            

            "hard":False,
            "use_uncertain":False,

            "uncertain":False,
            "ego_attention": False,
            "is_Dsac":False
        })
        return config

    def _reward(self, action: int) -> float:
        lane_change = action == 0 or action == 2
        if self.vehicle.speed ==0:
            self.wait_pen = 1
        else:
            self.wait_pen = 0
        
        #print(self.vehicle.velocity)
        #print(self.vehicle.action['acceleration'])
        # for vehicle in self.road.vehicles:
        #     if IntervalVehicle.handle_collisions(self.vehicle,vehicle,0.5):
        #         self.pre_collision = 1
        #     else:
        #         self.pre_collision = 0
        #print(self.vehicle.lane_index[1] is self.my_destinations)
        reward = self.config["collision_reward"] * self.vehicle.crashed \
            + self.config["high_speed_reward"] * \
                 MDPVehicle.get_speed_index(self.vehicle) / max(MDPVehicle.SPEED_COUNT - 1, 1) \
            + self.config["lane_change_reward"] * lane_change \
            + self.config["v_is_zero_reward"] * self.wait_pen \
            #+ self.config["collision_incoming"] * self.pre_collision
        return utils.lmap(reward,
                          [self.config["collision_reward"] + self.config["lane_change_reward"] + self.config["v_is_zero_reward"],
                           self.config["high_speed_reward"]], [0, 1])

    def _is_terminal(self) -> bool:
        """The episode is over when a collision occurs or when the access ramp has been passed."""
        return self.vehicle.crashed or self.steps >= self.config["duration"] or 
##################
    
    def vehicle_is_finish(self) -> bool:
        '''判断车辆是否到达指定位置'''
        return self.vehicle.lane_index[1] is self.my_destinations
    def vehicle_crash(self) -> bool:
        return self.vehicle.crashed    
##########################
    def _reset(self) -> None:
        self._make_road()
        self._make_vehicles()
        # try:
        #     self.unwrapped.configure(env_config)
        #     # Reset the environment to ensure configuration is applied
        #     self.reset()
    ####################################################
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, dict]:
        obs, reward, done, info = super().step(action)
        self._clear_vehicles()
        #self._spawn_vehicle(spawn_probability=self.config["spawn_probability"])#这个就是不确定性估计
        #self._make_vehicles()
        return obs, reward, done, info

    def _clear_vehicles(self) -> None:
        is_leaving = lambda vehicle: "il" in vehicle.lane_index[0] and "o" in vehicle.lane_index[1] \
                                     and vehicle.lane.local_coordinates(vehicle.position)[0] \
                                     >= vehicle.lane.length - 4 * vehicle.LENGTH
        self.road.vehicles = [vehicle for vehicle in self.road.vehicles if
                              vehicle in self.controlled_vehicles or not (is_leaving(vehicle) or vehicle.route is None)]
    ##################################

    def _make_road(self) -> None:
        # Circle lanes: (s)outh/(e)ast/(n)orth/(w)est (e)ntry/e(x)it.
        center = [0, 0]  # [m]
        radius = 20  # [m]
        alpha = 24  # [deg]

        net = RoadNetwork()
        radii = [radius, radius+4]
        n, c, s = LineType.NONE, LineType.CONTINUOUS, LineType.STRIPED
        line = [[c, s], [n, c]]
        for lane in [0, 1]:
            net.add_lane("se", "ex",
                         CircularLane(center, radii[lane], np.deg2rad(90 - alpha), np.deg2rad(alpha),
                                      clockwise=False, line_types=line[lane]))
            net.add_lane("ex", "ee",
                         CircularLane(center, radii[lane], np.deg2rad(alpha), np.deg2rad(-alpha),
                                      clockwise=False, line_types=line[lane]))
            net.add_lane("ee", "nx",
                         CircularLane(center, radii[lane], np.deg2rad(-alpha), np.deg2rad(-90 + alpha),
                                      clockwise=False, line_types=line[lane]))
            net.add_lane("nx", "ne",
                         CircularLane(center, radii[lane], np.deg2rad(-90 + alpha), np.deg2rad(-90 - alpha),
                                      clockwise=False, line_types=line[lane]))
            net.add_lane("ne", "wx",
                         CircularLane(center, radii[lane], np.deg2rad(-90 - alpha), np.deg2rad(-180 + alpha),
                                      clockwise=False, line_types=line[lane]))
            net.add_lane("wx", "we",
                         CircularLane(center, radii[lane], np.deg2rad(-180 + alpha), np.deg2rad(-180 - alpha),
                                      clockwise=False, line_types=line[lane]))
            net.add_lane("we", "sx",
                         CircularLane(center, radii[lane], np.deg2rad(180 - alpha), np.deg2rad(90 + alpha),
                                      clockwise=False, line_types=line[lane]))
            net.add_lane("sx", "se",
                         CircularLane(center, radii[lane], np.deg2rad(90 + alpha), np.deg2rad(90 - alpha),
                                      clockwise=False, line_types=line[lane]))

        # Access lanes: (r)oad/(s)ine
        access = 170  # [m]
        dev = 85  # [m]
        a = 5  # [m]
        delta_st = 0.2*dev  # [m]

        delta_en = dev-delta_st
        w = 2*np.pi/dev
        net.add_lane("ser", "ses", StraightLane([2, access], [2, dev/2], line_types=(s, c)))
        net.add_lane("ses", "se", SineLane([2+a, dev/2], [2+a, dev/2-delta_st], a, w, -np.pi/2, line_types=(c, c)))
        net.add_lane("sx", "sxs", SineLane([-2-a, -dev/2+delta_en], [-2-a, dev/2], a, w, -np.pi/2+w*delta_en, line_types=(c, c)))
        net.add_lane("sxs", "sxr", StraightLane([-2, dev / 2], [-2, access], line_types=(n, c)))

        net.add_lane("eer", "ees", StraightLane([access, -2], [dev / 2, -2], line_types=(s, c)))
        net.add_lane("ees", "ee", SineLane([dev / 2, -2-a], [dev / 2 - delta_st, -2-a], a, w, -np.pi / 2, line_types=(c, c)))
        net.add_lane("ex", "exs", SineLane([-dev / 2 + delta_en, 2+a], [dev / 2, 2+a], a, w, -np.pi / 2 + w * delta_en, line_types=(c, c)))
        net.add_lane("exs", "exr", StraightLane([dev / 2, 2], [access, 2], line_types=(n, c)))

        net.add_lane("ner", "nes", StraightLane([-2, -access], [-2, -dev / 2], line_types=(s, c)))
        net.add_lane("nes", "ne", SineLane([-2 - a, -dev / 2], [-2 - a, -dev / 2 + delta_st], a, w, -np.pi / 2, line_types=(c, c)))
        net.add_lane("nx", "nxs", SineLane([2 + a, dev / 2 - delta_en], [2 + a, -dev / 2], a, w, -np.pi / 2 + w * delta_en, line_types=(c, c)))
        net.add_lane("nxs", "nxr", StraightLane([2, -dev / 2], [2, -access], line_types=(n, c)))

        net.add_lane("wer", "wes", StraightLane([-access, 2], [-dev / 2, 2], line_types=(s, c)))
        net.add_lane("wes", "we", SineLane([-dev / 2, 2+a], [-dev / 2 + delta_st, 2+a], a, w, -np.pi / 2, line_types=(c, c)))
        net.add_lane("wx", "wxs", SineLane([dev / 2 - delta_en, -2-a], [-dev / 2, -2-a], a, w, -np.pi / 2 + w * delta_en, line_types=(c, c)))
        net.add_lane("wxs", "wxr", StraightLane([-dev / 2, -2], [-access, -2], line_types=(n, c)))

        road = Road(network=net, np_random=self.np_random, record_history=self.config["show_trajectories"])
        self.road = road
        

    def _make_vehicles(self) -> None:
        """
        Populate a road with several vehicles on the highway and on the merging lane, as well as an ego-vehicle.

        :return: the ego-vehicle
        """









        position_deviation = 2
        speed_deviation = 2

        # Ego-vehicle
        ego_destinations = ["exr", "sxr", "nxr"]
        ego_index = np.random.randint(0,3)
        
        ego_lane = self.road.network.get_lane(("ser", "ses", 0))

        ego_vehicle = self.action_type.vehicle_class(self.road,
                                                     ego_lane.position(125, 0),
                                                     speed=8,
                                                     heading=ego_lane.heading_at(140))
        
        if False:
            try:
                # ego_vehicle.plan_route_to("nxs")
                ego_vehicle.plan_route_to(ego_destinations[ego_index])
            except AttributeError:
                pass

            self.my_destinations = ego_destinations[ego_index]
        else:
            ego_vehicle.plan_route_to("nxr")
            self.my_destinations = ego_destinations[2]
        
        MDPVehicle.SPEED_MIN = 0
        MDPVehicle.SPEED_MAX = 16
        MDPVehicle.SPEED_COUNT = 3
        self.road.vehicles.append(ego_vehicle)
        self.vehicle = ego_vehicle

        # Incoming vehicle
        destinations = ["exr", "sxr", "nxr"]
        # try:

        if self.config["use_uncertain"]:
            other_vehicles_type = utils.class_from_path(self.config["my_other_vehicles_type"])  
        else:
            other_vehicles_type = utils.class_from_path(self.config["other_vehicles_type"])
         

        other_vehicles_type.DISTANCE_WANTED = 7  # Low jam distance
        other_vehicles_type.COMFORT_ACC_MAX = 6
        other_vehicles_type.COMFORT_ACC_MIN = -3
        
        vehicle = other_vehicles_type.make_on_lane(self.road,
                                                ("we", "sx", 1),
                                                longitudinal=5 + self.np_random.randn()*position_deviation,
                                                speed=16 + self.np_random.randn() * speed_deviation)   
         

        if self.config["incoming_vehicle_destination"] is not None:
            destination = destinations[self.config["incoming_vehicle_destination"]]
        else:
            destination = self.np_random.choice(destinations)
        vehicle.plan_route_to(destination)
        vehicle.randomize_behavior()
        self.road.vehicles.append(vehicle)

        # Other vehicles
        if self.config["hard"]:
            num_oth_vehicle1 = np.random.randint(2,4)
            num_oth_vehicle2 = np.random.randint(-4,0)
        else:
            num_oth_vehicle1 = np.random.randint(2,3)
            num_oth_vehicle2 = np.random.randint(-1,0)




        for i in list(range(1, num_oth_vehicle1)) + list(range(num_oth_vehicle2, 0)):

            vehicle = other_vehicles_type.make_on_lane(self.road,
                                                    ("we", "sx", 0),
                                                    longitudinal=18*i + self.np_random.randn()*position_deviation,
                                                    speed=16 + self.np_random.randn() * speed_deviation)
            vehicle.plan_route_to(self.np_random.choice(destinations))
            vehicle.randomize_behavior()
            self.road.vehicles.append(vehicle)

        # Entering vehicle
        # 随机选择n个四个方向的来车
        pre_rote = [("eer", "ees", 0),("ner", "nes", 0),("wer", "wes", 0),("ser", "ses", 0)]
        num_entering_vehicle = np.random.randint(0,4)
        pick_index1 = rand.sample(range(0,len(pre_rote)),num_entering_vehicle) 
        pick_index2 = rand.sample(range(0,len(pre_rote)),num_entering_vehicle) 

        # position1 = np.random.randint(45,55)
        # position2 = np.random.randint(65,75)
        for i in pick_index1:
            vehicle = other_vehicles_type.make_on_lane(self.road,
                                                    pre_rote[i],
                                                    longitudinal=50 + self.np_random.randn() * position_deviation,
                                                    speed=16 + self.np_random.randn() * speed_deviation)

            
            vehicle.plan_route_to(self.np_random.choice(destinations))
            vehicle.randomize_behavior()
            self.road.vehicles.append(vehicle)
        
        if self.config["hard"]:
            for j in pick_index2:
                vehicle = other_vehicles_type.make_on_lane(self.road,
                                                        pre_rote[j],
                                                        longitudinal=70 + self.np_random.randn() * position_deviation,
                                                        speed=16 + self.np_random.randn() * speed_deviation)

                
                vehicle.plan_route_to(self.np_random.choice(destinations))
                vehicle.randomize_behavior()
                self.road.vehicles.append(vehicle)


register(
    id='roundabout-v0',
    entry_point='highway_env.envs:RoundaboutEnv',
)
